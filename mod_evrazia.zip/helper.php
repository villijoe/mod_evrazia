<?php

defined('_JEXEC') or die('Restricted access');

class modEvraziaHelper
{
    public static function getAjax()
    {
        jimport('joomla.application.module.helper');
        jimport('joomla.database.database');
        $input = JFactory::getApplication()->input;

        $city = $input->getString('data');

        $db = JFactory::getDBO();
        if (!$db->connected()) {
            echo "No connect with server data base";
            jexit();
        } else {
            $query = $db->getQuery(true);
            $query->select($db->quoteName(array('id')));
            $query->from($db->quoteName('#__citis'));
            $query->where($db->quoteName('title') . ' = ' . $db->quote($city));

            $db->setQuery($query);
            $list = $db->loadObjectList();

            if (empty($list[0])) {
                return 'Такого города в базе данных не существует';
            } else {
                foreach ($list as $town) {
                    return 'id введенного вами города - ' . $town->id;
                }
            }
        }

    }
}