<?php ?>
<div id="form_city">
    <form method="POST" id="form">
        <input type="text" name="city" class="input-block-level" placeholder="Enter city" required="required" />
        <input type="button" id="submit" value="Вывести id" name="mod_evrazia_submitted" class="btn btn-block btn-large btn-info" />
    </form>
    <div id="answer"></div>
</div>



