<?php

defined('_JEXEC') or die('Restricted access');

require_once __DIR__ . '/helper.php';

$doc = JFactory::getDocument();

$js = <<<JS
(function ($) {

    function send_ajax(){
        var value = $('input[name=city]').val();
        if (value === '') {
            return false;
        }
        $.ajax({
            type: 'POST',
            dataType: 'json',
            data: {
                option: 'com_ajax',
                module: 'evrazia',
                data: value,
                format: 'json'
            },
            success: function(response){
                $('#answer').text(response.data);
            }
        });
        return false;
    }

    $(document).ready(function() {
        $(window).keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                send_ajax();
            }
        });
    });

    $(document).on('click', 'input[type=button]', function(){
        send_ajax();
    });

})(jQuery);
JS;

$doc->addScriptDeclaration($js);

require(JModuleHelper::getLayoutPath('mod_evrazia'));