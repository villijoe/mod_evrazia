CREATE TABLE IF NOT EXISTS `#__citis` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

INSERT INTO `#__citis` (`title`) VALUES ('Москва');
INSERT INTO `#__citis` (`title`) VALUES ('Киев');
INSERT INTO `#__citis` (`title`) VALUES ('Минск');
INSERT INTO `#__citis` (`title`) VALUES ('Одесса');
INSERT INTO `#__citis` (`title`) VALUES ('Санкт-Петербург');
INSERT INTO `#__citis` (`title`) VALUES ('Днепропетровск');
INSERT INTO `#__citis` (`title`) VALUES ('Львов');
INSERT INTO `#__citis` (`title`) VALUES ('Харьков');
INSERT INTO `#__citis` (`title`) VALUES ('Херсон');
INSERT INTO `#__citis` (`title`) VALUES ('Полтава');
INSERT INTO `#__citis` (`title`) VALUES ('Кировоград');
INSERT INTO `#__citis` (`title`) VALUES ('Житомир');
INSERT INTO `#__citis` (`title`) VALUES ('Новосибирск');
INSERT INTO `#__citis` (`title`) VALUES ('Екатеринбург');
INSERT INTO `#__citis` (`title`) VALUES ('Кривой Рог');
INSERT INTO `#__citis` (`title`) VALUES ('Николаев');